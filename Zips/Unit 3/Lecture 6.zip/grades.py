# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 19:26:05 2016

@author: ericgrimson
"""

grades = {'Ana':'B', 'John':'A+', 'Denise':'A', 'Katy':'A'}
